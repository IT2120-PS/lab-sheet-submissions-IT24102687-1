setwd("C:\\Users\\CHENUMI\\Desktop\\Lab 9")
#Exercise
set.seed(123)

sample_size <- 25
mu <-45
sigma <-2
baking_times <- rnorm(sample_size, mean = mu, sd = sigma)
print(baking_times)

t_test_results <- t.test(baking_times, mu = 46, alternative = "less")
print(t_test_results)


#Q1
x <- c(3, 7, 11, 0, 7, 0, 4, 5, 6, 2)
t.test (x, mu = 3)

#Q2 Part1
Weight <- c(1/.6, 20.6, 22.2, 15.3, 20.9, 21.0, 18.9, 18.9, 18.9, 18.2)
t.test(Weight , mu=25 , alternative= "less")

#Part 2
res <- t.test(Weight , mu=25 , alternative= "less")

res$statistic

res$p.value

res$conf.int

#Q3 
y <- rnorm(30, mean = 9.8, sd = 0.05)

t.test(y , mu=10 , alternative= "greater")

#Exercise

