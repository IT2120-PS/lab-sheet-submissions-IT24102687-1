setwd("C:\\Users\\CHENUMI\\Desktop\\IT24102687")

data<- read.table("Data - Lab 8.txt", header=TRUE)
fix(data)
attach (data)

popmn <- mean (Nicotine)
popmn 

popvar <- var (Nicotine)
popvar

samples<-c()
samples
n<-c()
n

for(i in 1:30){
  s<-sample(Nicotine,5,replace=TRUE)
  samples <- cbind(samples, s)
  n <- c(n,paste('S',i))
}
colnames(samples)=n

s.means<-apply(samples,2,mean)
s.means
s.vars<-apply(samples,2,var)
s.vars

samplemean<-mean(s.means)
samplemean

samplevars<-var(s.means)
samplevars

popmn
samplemean

truevar=popvar/5
truevar
samplevars